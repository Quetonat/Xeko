require('../styles/main.scss');
require('../styles/menu.scss');
require('../styles/scheme.scss');
