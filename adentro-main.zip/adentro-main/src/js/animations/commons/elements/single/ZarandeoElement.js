import SingleElement from './SingleElement';

export default class ZarandeoElement extends SingleElement {
	constructor(animation, pathStrings, figure) {
		super(animation, pathStrings, 'woman', figure);
	}
}
