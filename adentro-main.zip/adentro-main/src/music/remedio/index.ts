module.exports = {
	name: 'Remedio  Norteño',
	scheme: require('./scheme.yaml'),
	music: [
		require('./music/remedio_norteno'),
	],
	animation: require('js/animations/RemedioAnimation').default,
	zapateo: true
};
