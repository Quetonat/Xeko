module.exports = {
	name: 'Arunguita',
	scheme: require('./scheme.yaml'),
	music: [
		require('./music/hugo_torres_-_la_arunguita'),
	],
	animation: require('js/animations/ArunguitaAnimation').default
};
