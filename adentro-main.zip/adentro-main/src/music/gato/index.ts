module.exports = {
	name: 'Gato',
	scheme: require('./scheme.yaml'),
	music: [
		require('./music/gatito_pa_don_lucas'),
	],
	animation: require('js/animations/GatoAnimation').default,
	zapateo: true
};
