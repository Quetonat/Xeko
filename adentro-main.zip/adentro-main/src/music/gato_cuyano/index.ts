module.exports = {
	name: 'Gato Cuyano',
	scheme: require('./scheme.yaml'),
	music: [
		require('./music/el_correcto'),
	],
	animation: require('js/animations/GatoAnimation').default
};
