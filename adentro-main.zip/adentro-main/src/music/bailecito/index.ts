module.exports = {
	name: 'Bailecito',
	scheme: require('./scheme.yaml'),
	music: [
		require('./music/toda_la_noche'),
	],
	animation: require('js/animations/BailecitoAnimation').default
};
