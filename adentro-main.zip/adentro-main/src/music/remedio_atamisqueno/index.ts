module.exports = {
	name: 'Remedio Atamisqueño',
	scheme: require('./scheme.yaml'),
	music: [
		require('./music/remedio_atamisqueno'),
	],
	animation: require('js/animations/RemedioAnimation').default,
	zapateo: true
};
